import Methods.Company;
import UI.Operator;

public class Main {
	public static void main(String[] args) {
		Company company = new Company();
		Operator operator = new Operator();
		operator.start();
	}
}

// https://www.devmedia.com.br/trabalhando-com-as-classes-date-calendar-e-simpledateformat-em-java/27401